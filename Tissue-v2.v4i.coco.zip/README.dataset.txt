# Tissue-v2 > 2024-05-08 10:06pm
https://universe.roboflow.com/project-54tr5/tissue-v2

Provided by a Roboflow user
License: Public Domain

